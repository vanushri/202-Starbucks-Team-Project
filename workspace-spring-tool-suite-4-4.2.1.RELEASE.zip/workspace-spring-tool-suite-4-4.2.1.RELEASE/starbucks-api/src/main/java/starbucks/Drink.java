package starbucks;

public interface Drink {

	public double drinkCost(String size);
	
}

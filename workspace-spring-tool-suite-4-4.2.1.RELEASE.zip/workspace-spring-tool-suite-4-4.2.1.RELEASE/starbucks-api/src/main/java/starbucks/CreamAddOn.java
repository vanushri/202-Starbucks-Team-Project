package starbucks;

public class CreamAddOn implements AddOns{


	private final double cost = 1.5;

	@Override
	public double addOnCost() {

		return cost;
	}

}

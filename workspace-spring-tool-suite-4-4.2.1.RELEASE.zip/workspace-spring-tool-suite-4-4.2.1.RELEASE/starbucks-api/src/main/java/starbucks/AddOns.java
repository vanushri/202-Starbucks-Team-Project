package starbucks;

public interface AddOns {

	public double addOnCost();
	
}

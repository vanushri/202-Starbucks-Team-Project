package starbucks;
import java.util.ArrayList;
import java.util.List;

public class TestMain {
	
	
	
	public static void main(String[] args) {
		
		
		AddCard addCard = new AddCard();
		String resp = addCard.addStrabucksCard("123456789", "101", 1.0);
		
//		MakePayment pay = new MakePayment();
//		String resp2 = pay.makePayment();
		
		
		ManageOrder order = new ManageOrder();
		OrderItem orderItem = new OrderItem();
		List<OrderItem> finalOrder = new ArrayList<OrderItem>();
		List<String> addOn = new ArrayList<String>();
		
		orderItem.setItemCode("CafeMocha");
		orderItem.setPickUpLoc("Downtown");
		orderItem.setSize("S");
		orderItem.setAddOns("Cream");
		
		finalOrder.add(orderItem);
		
		String resp1 = order.manageOrder(finalOrder);
		
		System.out.println("Order successfully placed "+ resp);
	}

}

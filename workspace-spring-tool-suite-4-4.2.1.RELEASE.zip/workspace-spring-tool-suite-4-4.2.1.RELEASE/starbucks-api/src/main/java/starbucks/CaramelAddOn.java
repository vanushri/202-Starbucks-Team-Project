package starbucks;

public class CaramelAddOn implements AddOns{


	private final double cost = 1.0;

	@Override
	public double addOnCost() {

		return cost;
	}

}

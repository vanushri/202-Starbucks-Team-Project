package starbucks.order;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import starbucks.AddCard;

@RestController
public class Test2 {
	
	@RequestMapping("/hi")
	public String addCard() {
		AddCard addCard = new AddCard();
		String resp = addCard.addStrabucksCard("999999999", "333", 50.0);
		return "hi";
	}
	
}
